<?php

include_once BRIDGE_CORE_MODULES_PATH.'/shortcodes/lib/shortcode-functions.php';