(function($) {
	'use strict';
	
	$(document).ready(function(){
		qodeInitSplitScrollingSection();
	});
	
	/*
	 **	Split Scrolling Section
	 */
	function qodeInitSplitScrollingSection() {}
	
})(jQuery);